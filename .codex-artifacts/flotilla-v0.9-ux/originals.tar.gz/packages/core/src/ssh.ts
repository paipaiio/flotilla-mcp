/**
 * SSH transport built on ssh2, with:
 * - connection pooling keyed by server name
 * - auth cascade: SSH agent -> key file -> env password (never CLI args)
 * - TOFU host-key verification within the process lifetime; trustedHostKey pins
 *   are the only control that survives restarts
 * - ProxyJump via forwardOut through a bastion server (no agent forwarding)
 */
import { readFileSync, statSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { dirname as posixDirname } from "node:path/posix";
import { Client, type ClientChannel, type ConnectConfig, type SFTPWrapper } from "ssh2";
import { defaultKeychainBackend, resolveServerSecret } from "./keychain.js";
import type { ExecOptions, ExecResult, RelayResult, ServerConfig, TransferResult, Transport } from "./types.js";

/**
 * RFC 9142 algorithm allowlist — SHA-1 constructions (ssh-rsa, group1/14-sha1,
 * hmac-sha1), CBC ciphers, and arcfour/3des are out. On by default; a server
 * can opt back into ssh2's full negotiation set with allowLegacyAlgorithms.
 */
export const STRICT_ALGORITHMS = {
  kex: [
    "curve25519-sha256",
    "curve25519-sha256@libssh.org",
    "ecdh-sha2-nistp256",
    "ecdh-sha2-nistp384",
    "ecdh-sha2-nistp521",
    "diffie-hellman-group14-sha256",
    "diffie-hellman-group16-sha512",
    "diffie-hellman-group18-sha512",
  ],
  serverHostKey: [
    "ssh-ed25519",
    "ecdsa-sha2-nistp256",
    "ecdsa-sha2-nistp384",
    "ecdsa-sha2-nistp521",
    "rsa-sha2-512",
    "rsa-sha2-256",
  ],
  cipher: [
    "chacha20-poly1305@openssh.com",
    "aes128-gcm@openssh.com",
    "aes256-gcm@openssh.com",
    "aes128-ctr",
    "aes192-ctr",
    "aes256-ctr",
  ],
  hmac: [
    "hmac-sha2-256-etm@openssh.com",
    "hmac-sha2-512-etm@openssh.com",
    "hmac-sha2-256",
    "hmac-sha2-512",
  ],
  compress: ["none", "zlib@openssh.com"],
} as const;

/**
 * The algorithm set for a connection: the strict allowlist unless globally
 * disabled or the server is flagged legacy. Undefined = ssh2 defaults.
 */
export function effectiveAlgorithms(
  strict: boolean,
  allowLegacy: boolean | undefined,
): ConnectConfig["algorithms"] | undefined {
  if (!strict || allowLegacy) return undefined;
  // ssh2 mutates nothing but types want a plain record; cast off const.
  return STRICT_ALGORITHMS as unknown as ConnectConfig["algorithms"];
}

function expandHome(p: string): string {
  if (p === "~") return homedir();
  if (p.startsWith("~/")) return join(homedir(), p.slice(2));
  return p;
}

/**
 * Credential cascade: env var first (explicit operator choice), then the OS
 * keychain. The keychain backend is resolved lazily and its absence (no
 * prebuilt binary, no Secret Service daemon) degrades to env-only.
 */
async function serverSecret(server: ServerConfig, kind: "password" | "sudo"): Promise<string | undefined> {
  return resolveServerSecret(server, kind, process.env, await defaultKeychainBackend());
}

export class SshTransport implements Transport {
  private readonly pool = new Map<string, Client>();
  private readonly connecting = new Map<string, Promise<Client>>();
  /** TOFU store: process-lifetime only, nothing written to disk. */
  private readonly knownHostKeys = new Map<string, string>();
  /** Last use per pooled connection; drives idle reaping. */
  private readonly lastUsed = new Map<string, number>();
  private readonly idleReapMs: number;
  private readonly strictAlgorithms: boolean;
  private readonly reapTimer: NodeJS.Timeout;

  constructor(
    private readonly serversByName: Map<string, ServerConfig>,
    opts: { idleReapMs?: number; strictAlgorithms?: boolean } = {},
  ) {
    this.idleReapMs = opts.idleReapMs ?? 15 * 60_000;
    this.strictAlgorithms = opts.strictAlgorithms ?? true;
    // unref'd so the timer never keeps the process alive on its own.
    this.reapTimer = setInterval(() => this.reapIdle(), 60_000);
    this.reapTimer.unref();
  }

  /** Close pooled connections idle longer than idleReapMs. */
  reapIdle(now = Date.now()): number {
    let reaped = 0;
    for (const [name, conn] of this.pool) {
      const used = this.lastUsed.get(name) ?? now;
      if (now - used > this.idleReapMs) {
        try {
          conn.end();
        } catch {
          /* ignore */
        }
        this.pool.delete(name);
        this.lastUsed.delete(name);
        reaped++;
      }
    }
    return reaped;
  }

  private touch(name: string): void {
    this.lastUsed.set(name, Date.now());
  }

  /** The TOFU-accepted host key for a connected server, "SHA256:..." form. */
  hostKeyOf(name: string): string | undefined {
    const k = this.knownHostKeys.get(name);
    return k ? `SHA256:${k}` : undefined;
  }

  async exec(
    server: ServerConfig,
    command: string,
    opts: ExecOptions,
  ): Promise<ExecResult> {
    let password: string | undefined;
    if (opts.sudo) {
      // Password is optional: with NOPASSWD sudoers rules none is needed.
      password = await serverSecret(server, "sudo");
    }
    const conn = await this.connection(server);
    this.touch(server.name);
    const baseCommand = opts.workdir
      ? `cd ${shellQuote(opts.workdir)} && ${command}`
      : command;
    let fullCommand = baseCommand;
    if (opts.sudo) {
      // Two modes:
      // - password configured: `sudo -S -p ''` reads it from stdin (never
      //   argv, prompt suppressed so it can't leak into stderr)
      // - no password: `sudo -n` runs non-interactively — NOPASSWD rules
      //   succeed, anything else fails immediately instead of hanging
      // The command is NOT wrapped in sh -c: ssh2's exec channel already runs
      // it through the remote shell, and a wrapper would break sudoers
      // command whitelists (sudo would see sh, not the real command).
      // With workdir, cd happens as the user before sudo.
      const sudoPrefix = password ? "sudo -S -p ''" : "sudo -n";
      fullCommand = opts.workdir
        ? `cd ${shellQuote(opts.workdir)} && ${sudoPrefix} ${command}`
        : `${sudoPrefix} ${command}`;
    }
    const timeoutMs = opts.timeoutMs ?? 60_000;
    const started = Date.now();

    return new Promise<ExecResult>((resolve, reject) => {
      let settled = false;
      let timer: NodeJS.Timeout | undefined;
      let channel: ClientChannel | undefined;

      const finish = (fn: () => void): void => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        fn();
      };

      conn.exec(fullCommand, (err, ch) => {
        if (err) {
          // Drop a possibly-dead connection so the next call reconnects.
          this.drop(server.name);
          finish(() => reject(err));
          return;
        }
        channel = ch;
        if (password !== undefined) {
          ch.write(password + "\n");
        }
        let stdout = "";
        let stderr = "";
        let exitCode: number | null = null;

        ch.on("data", (d: Buffer) => {
          stdout += d.toString("utf8");
        });
        ch.stderr.on("data", (d: Buffer) => {
          stderr += d.toString("utf8");
        });
        ch.on("exit", (code: number | null) => {
          exitCode = code;
        });
        ch.on("close", () => {
          finish(() =>
            resolve({
              host: server.name,
              ok: exitCode === 0,
              exitCode,
              stdout,
              stderr,
              durationMs: Date.now() - started,
            }),
          );
        });
        ch.on("error", (e: Error) => {
          finish(() => reject(e));
        });

        timer = setTimeout(() => {
          try {
            channel?.close();
          } catch {
            /* channel already gone */
          }
          finish(() =>
            reject(new Error(`Command timed out after ${timeoutMs}ms on ${server.name}`)),
          );
        }, timeoutMs);
      });
    });
  }

  /**
   * SFTP upload: mkdir -p the remote parent, then fastPut. Overwrites existing
   * files. The bytes reported come from the local file's stat — what was sent.
   */
  async upload(
    server: ServerConfig,
    localPath: string,
    remotePath: string,
    opts: ExecOptions,
  ): Promise<TransferResult> {
    const started = Date.now();
    const bytes = statSync(expandHome(localPath)).size;
    const conn = await this.connection(server);
    this.touch(server.name);

    const dir = posixDirname(remotePath);
    if (dir && dir !== "/" && dir !== ".") {
      await this.exec(server, `mkdir -p ${shellQuote(dir)}`, opts);
    }

    const sftp = await new Promise<SFTPWrapper>((resolve, reject) => {
      conn.sftp((err, s) => (err ? reject(err) : resolve(s)));
    });
    try {
      await new Promise<void>((resolve, reject) => {
        sftp.fastPut(expandHome(localPath), remotePath, (err) =>
          err ? reject(err) : resolve(),
        );
      });
    } finally {
      sftp.end();
    }
    return { host: server.name, ok: true, bytes, durationMs: Date.now() - started };
  }

  /** SFTP download: fastGet remotePath to localPath (parent dir must exist locally). */
  async download(
    server: ServerConfig,
    remotePath: string,
    localPath: string,
    _opts: ExecOptions,
  ): Promise<TransferResult> {
    const started = Date.now();
    const conn = await this.connection(server);
    this.touch(server.name);

    const sftp = await new Promise<SFTPWrapper>((resolve, reject) => {
      conn.sftp((err, s) => (err ? reject(err) : resolve(s)));
    });
    try {
      await new Promise<void>((resolve, reject) => {
        sftp.fastGet(remotePath, expandHome(localPath), (err) =>
          err ? reject(err) : resolve(),
        );
      });
    } finally {
      sftp.end();
    }
    const bytes = statSync(expandHome(localPath)).size;
    return { host: server.name, ok: true, bytes, durationMs: Date.now() - started };
  }

  /**
   * Server-to-server relay: open an SFTP read stream on src and pipe it into an
   * SFTP write stream on dst. Bytes flow through this process's memory only —
   * the control machine never writes a copy to disk. The destination parent
   * directory is created first; an existing destination file is overwritten.
   */
  async relayCopy(
    src: ServerConfig,
    srcPath: string,
    dst: ServerConfig,
    dstPath: string,
    opts: ExecOptions,
  ): Promise<RelayResult> {
    const started = Date.now();
    const base = { source: src.name, dest: dst.name };

    const dir = posixDirname(dstPath);
    if (dir && dir !== "/" && dir !== ".") {
      const mkdir = await this.exec(dst, `mkdir -p ${shellQuote(dir)}`, opts);
      if (!mkdir.ok) {
        return {
          ...base, ok: false, bytes: 0, durationMs: Date.now() - started,
          error: `mkdir ${dir} failed on ${dst.name}: ${mkdir.stderr.trim() || mkdir.error}`,
        };
      }
    }

    const srcConn = await this.connection(src);
    const dstConn = await this.connection(dst);
    this.touch(src.name);
    this.touch(dst.name);

    const srcSftp = await new Promise<SFTPWrapper>((resolve, reject) => {
      srcConn.sftp((err, s) => (err ? reject(err) : resolve(s)));
    });
    const dstSftp = await new Promise<SFTPWrapper>((resolve, reject) => {
      dstConn.sftp((err, s) => (err ? reject(err) : resolve(s)));
    });

    try {
      const bytes = await new Promise<number>((resolve, reject) => {
        let n = 0;
        let settled = false;
        const fail = (err: Error) => {
          if (settled) return;
          settled = true;
          read.destroy();
          write.destroy();
          reject(err);
        };
        const read = srcSftp.createReadStream(srcPath);
        const write = dstSftp.createWriteStream(dstPath);
        read.on("data", (chunk: Buffer) => { n += chunk.length; });
        read.on("error", fail);
        write.on("error", fail);
        write.on("close", () => {
          if (settled) return;
          settled = true;
          resolve(n);
        });
        read.pipe(write);
      });
      return { ...base, ok: true, bytes, durationMs: Date.now() - started };
    } finally {
      srcSftp.end();
      dstSftp.end();
    }
  }

  async close(): Promise<void> {
    clearInterval(this.reapTimer);
    for (const [name, conn] of this.pool) {
      try {
        conn.end();
      } catch {
        /* ignore */
      }
      this.pool.delete(name);
      this.lastUsed.delete(name);
    }
  }

  private drop(name: string): void {
    const conn = this.pool.get(name);
    if (conn) {
      try {
        conn.end();
      } catch {
        /* ignore */
      }
      this.pool.delete(name);
      this.lastUsed.delete(name);
    }
  }

  private connection(server: ServerConfig): Promise<Client> {
    const pooled = this.pool.get(server.name);
    if (pooled) return Promise.resolve(pooled);

    // Deduplicate concurrent connect attempts for the same server.
    const pending = this.connecting.get(server.name);
    if (pending) return pending;

    const attempt = this.connect(server)
      .then((conn) => {
        this.pool.set(server.name, conn);
        conn.on("close", () => {
          this.pool.delete(server.name);
          this.lastUsed.delete(server.name);
        });
        conn.on("error", () => {
          this.pool.delete(server.name);
          this.lastUsed.delete(server.name);
        });
        return conn;
      })
      .finally(() => this.connecting.delete(server.name));
    this.connecting.set(server.name, attempt);
    return attempt;
  }

  private async connect(server: ServerConfig): Promise<Client> {
    const config = await this.connectConfig(server);

    if (!server.via) return openConnection(config);

    const bastionConfig = this.serversByName.get(server.via);
    if (!bastionConfig) {
      throw new Error(`Jump host "${server.via}" not found for server "${server.name}"`);
    }
    const bastion = await this.connection(bastionConfig);
    const stream = await new Promise<ClientChannel>((resolve, reject) => {
      bastion.forwardOut(
        "127.0.0.1",
        0,
        server.host,
        server.port,
        (err, ch) => (err ? reject(err) : resolve(ch)),
      );
    });
    return openConnection({ ...config, sock: stream });
  }

  private async connectConfig(server: ServerConfig): Promise<ConnectConfig> {
    const base: ConnectConfig = {
      host: server.host,
      port: server.port,
      username: server.user,
      readyTimeout: 20_000,
      hostHash: "sha256",
      hostVerifier: (hashedKey: string) => this.verifyHostKey(server, hashedKey),
    };

    const algorithms = effectiveAlgorithms(this.strictAlgorithms, server.allowLegacyAlgorithms);
    if (algorithms) base.algorithms = algorithms;

    switch (server.auth) {
      case "agent":
        if (process.env.SSH_AUTH_SOCK) {
          base.agent = process.env.SSH_AUTH_SOCK;
          break;
        }
        throw new Error(
          `Server "${server.name}" uses auth="agent" but SSH_AUTH_SOCK is not set`,
        );
      case "key":
        base.privateKey = readFileSync(expandHome(server.keyRef!), "utf8");
        break;
      case "password": {
        const password = await serverSecret(server, "password");
        if (!password) {
          throw new Error(
            `No password for "${server.name}": set FLOTILLA_${server.name
              .toUpperCase()
              .replace(/[^A-Z0-9]/g, "_")}_PASSWORD / FLOTILLA_PASSWORD, ` +
              `or store it in the OS keychain (flotilla keychain set ${server.name})`,
          );
        }
        base.password = password;
        break;
      }
    }
    return base;
  }

  /**
   * TOFU within the process: first sighting of a host key is accepted and
   * remembered; a later mismatch in the same process fails the connection.
   * A configured trustedHostKey pin always wins and is never overridden.
   */
  private verifyHostKey(server: ServerConfig, hashedKey: string): boolean {
    const pinned = server.trustedHostKey;
    if (pinned) {
      const expected = pinned.startsWith("SHA256:") ? pinned.slice("SHA256:".length) : pinned;
      return hashedKey === expected;
    }
    const known = this.knownHostKeys.get(server.name);
    if (known === undefined) {
      this.knownHostKeys.set(server.name, hashedKey);
      return true;
    }
    return known === hashedKey;
  }
}

function openConnection(config: ConnectConfig): Promise<Client> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn.once("ready", () => resolve(conn));
    conn.once("error", reject);
    conn.connect(config);
  });
}

function shellQuote(s: string): string {
  return `'${s.replace(/'/g, `'\\''`)}'`;
}
